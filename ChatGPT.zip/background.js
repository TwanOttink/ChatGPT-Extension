chrome.tabs.create({ url: 'https://chat.openai.com/' });
window.close();